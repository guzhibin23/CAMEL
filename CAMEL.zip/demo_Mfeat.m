
clear 
clc

cur_folder = pwd;
addpath([cur_folder, '\funs']);
addpath([cur_folder, '\dataset']);
Dataname = ["Mfeat"];
percentDel = [0.3];

%% =====================Parameter setting===============================
result=[];
max_val=0;
ii=0;
mean_time=0;
times=5;

%% ===================== Optimization ==================================
for it_name = 1:length(Dataname)
    for j = 1:length(percentDel)
        %% =====================Load Datatset=======================
        [X,truthF,ind_folds,X_com]=prepareMissingData(char(Dataname(it_name)),percentDel(j));
        
        cls_num = length(unique(truthF));
        anchor=[cls_num,2*cls_num,3*cls_num,4*cls_num,5*cls_num];

        for iv = 1:length(X)
            %% =====================Constructing a matrix of missing data========================
            X1 = X{iv}';%X1
            X1 = NormalizeFea(X1,0);%Normalization
            X_com{iv}=X_com{iv}';
            X_com{iv}= NormalizeFea(X_com{iv},0);
            ind_0 = find(ind_folds(:,iv) == 0);
            ind_1 = find(ind_folds(:,iv) == 1);
            X1(:,ind_0) = 0;
            X_mis{iv} = X1;
            X_mis_ind{iv} = ind_0 ;
            X_com_ind{iv}=ind_1;
            %% ========================================dimen==========================================
            dimen(iv)=min(12,round(size(X1,1)/4));
            %dimen(iv)=min(20,round(size(X1,1)/2));% cifar10
            Nv(iv) =length(ind_1);
        end
        
        %% =================================== Adjusting hyperparameters============================
        for i_lambda1 = -3%-8:1:-3
            for i_lambda2 = -3%-4:1:-2
                for i_delta =-2%-4:1:-1
                    for i_anchor = 2%1:5
                        for ii = 1:1:times
                        lambda1 = 10^(i_lambda1);
                        lambda2 = 10^(i_lambda2);
                        delta=10^(i_delta);
                        anc = anchor(i_anchor);
                        tic;
                         [y,Z,~,~,E,Y,A,X,H] = CAMEL(X_mis,Nv,cls_num,X_mis_ind,X_com_ind,lambda1,lambda2,delta,anc,dimen);  
                        time = toc;                 
                        mean_time=mean_time+time;
                        result(ii,:) = ClusteringMeasure(truthF, y);
                        if ii==1
                            min_val=result(ii,1);
                        end
                        %% ===========================Saving the best results===========================
                        if result(ii,1)<min_val
                            min_val=result(ii,1);
                        end
                        if result(ii,1) > max_val
                            max_val = result(ii,1);
                            record = [lambda1,lambda2,anc,time];
                            record_result = result(ii,:);
                        end
                        end
                        mean_time=mean_time/times;
                    end
                end
            end
        end
        mean_acc=sum(result(:,1))/size(result,1);
        mean_nmi=sum(result(:,2))/size(result,1);
        mean_pur=sum(result(:,3))/size(result,1);
        s_acc = std(result(:,1));
        s_nmi = std(result(:,2));
        s_purity = std(result(:,3));
        fprintf('mean_acc = %.4f, mean_nmi = %.4f, mean_pur = %.4f, std_acc = %.4f, std_nmi = %.4f, std_pur = %.4f\n', ...
    mean_acc, mean_nmi, mean_pur, s_acc, s_nmi, s_purity);
        save(strcat('.\result\CAMEL_',num2str(percentDel(j)),'_',Dataname(it_name),'.mat'),'result','record','mean_acc','mean_nmi','mean_pur','s_acc','s_nmi','s_purity','mean_time')
    end
end