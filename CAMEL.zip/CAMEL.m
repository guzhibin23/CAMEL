function [labels,Z,converge_Z,converge_H_G,E,Y,A,X,H]= CAMEL(X,Nv,cls_num,X_mis_ind,X_com_ind,lambda1,lambda2,delta,anc,dimen)
    
m = length(X);
n = size(X{1},2);
t=anc;%anchors
nC=cls_num;
s=nC;
rank_fun=3;
%% ======================= Dimension reduction =================
for v=1:m
    valid_indices = X_com_ind{v};
    X_valid = X{v}(:, valid_indices); 
    [~, score, ~] = pca(X_valid');
    X_reduced{v} = score(:,1:min(min(size(X_valid',1)-1,size(X_valid',2)),dimen(v)))';
    X_restored = zeros(size(X_reduced{v}, 1), n); 
    X_restored(:, valid_indices) = X_reduced{v};
    X{v} = X_restored;
end 

%% ======================= Initialization ====================
[UH, ~, ~] = svds(cell2mat(X')', nC);
for v =1:m
    Z{v}=zeros(t,n);
    Z{v}(:,X_mis_ind{v}) = ones(t,n-Nv(v));
    
    E{v} = zeros(size(X{v},1),n);
    A{v} = zeros(size(X{v},1),t);
    Y{v} = zeros(size(X{v},1),n);
    H{v} = UH;
    W{v} = zeros(n,nC);
    G{v} = zeros(n,nC);
end

Isconverg = 0;
iter = 0;
max_iter=200;
epson = 1e-5;
alp=0.001;
bet=10000;
par1=2*(alp-lambda2);
par2=2*lambda2/bet;

mu = 10e-4; max_mu = 10e12; eta_mu = 1.2;
zeta = 10e-4; max_zeta = 10e12; eta_zeta = 1.2;

sX = [n,nC,m];
converge_Z=[];
converge_H_G=[];
%% ================================ Update ================================
while(Isconverg == 0)
%% ============================== Upadate A^v =============================
    for v = 1:m
        M{v}=(Y{v}+mu*X{v}-mu*E{v})*Z{v}';
        [UA,~,VA] = svd(M{v},'econ');
        A{v} = UA*VA';
    end
%% ============================== Upadate E^v =============================
    for v = 1:m
        E{v}=(Y{v}+mu*(X{v}-A{v}*Z{v}))/(2*lambda1+mu);
    end
%% ============================== Update Z^v =============================
    for v = 1:m
       Z{v}=max(0,(A{v}'*(Y{v}+mu*(X{v}-E{v})))/mu);
    end
    %% ============================== Update H^v =============================
    for v = 1:m
        F{v} = par1*H{v}+par2*Z{v}'*(Z{v}*H{v})+zeta*G{v}-W{v};
        [UH, ~, VH] = svds(F{v}, nC);
        H{v} = UH*VH';
        
    end
%% ============================== Update Y^v =============================
for v=1:m
   Y{v} = Y{v} + mu*(X{v}-A{v}*Z{v}-E{v});
end
%% ============================= Update G^v ==============================
H_tensor = cat(3, H{:,:});
W_tensor = cat(3, W{:,:});
%nonconvex function
G_tensor = solve_G_fun(H_tensor + 1/zeta*W_tensor,zeta,sX,delta,rank_fun);
for v =1:m
    G{v} = G_tensor(:,:,v);
end
%% ============================== Update W ===============================
W_tensor = W_tensor+zeta*(H_tensor-G_tensor);
for v=1:m
    W{v} = W_tensor(:,:,v);
end
%% =============================== Update X ===============================
for v=1:m
    temp=A{v}*Z{v};
    X{v}(:,X_mis_ind{v})=temp(:,X_mis_ind{v});
end

%% ============================= Update penalty parameters ===============
mu = min(mu*eta_mu, max_mu);
zeta = min(zeta*eta_zeta,max_zeta);
%% ====================== Checking Coverge Condition ======================
max_Z=0;
max_H_G=0;
history = struct();
Isconverg = 1;
for v=1:m
    first_norm=norm(X{v}-A{v}*Z{v}-E{v},inf);
    if (first_norm>epson)
        history.norm_Z = first_norm;
        Isconverg = 0;
        max_Z=max(max_Z,history.norm_Z );
    end

    sec_norm=norm(H{v}-G{v},inf);
    if (sec_norm>epson)
        history.norm_H_G = sec_norm;
        Isconverg = 0;
        max_H_G=max(max_H_G, history.norm_H_G);
    end
end
converge_Z=[converge_Z max_Z];
converge_H_G=[converge_H_G max_H_G];
fprintf('iter = %d, max_Z = %f, max_H_G = %f\n', iter, max_Z, max_H_G);

if (iter>max_iter)
    Isconverg  = 1;
end

iter=iter+1;

end

    Sbar=[];
    for i = 1:m
        Sbar=cat(2,Sbar,H{i});
    end

    labels=litekmeans(Sbar, nC, 'MaxIter', 100,'Replicates',10);
end