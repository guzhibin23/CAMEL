function y = rank_fun_derivative(x,delta,rank_fun)
switch rank_fun
    case 3 %l_delta function
         y= (delta+delta^2)./(delta+x).^2; 
    otherwise
        error('Unsupported rank function');
end
