function [X, truth, folds, X_com] = prepareMissingData(datasetName, missingRate)
    %X:n x d_v
    dataPath = sprintf('dataset\\%s.mat', datasetName);
    load(dataPath); 

    % 根据数据集名称设定视图变量（可拓展）
    switch datasetName
        case 'MSRC_v1'%ours%SCSL%IMVC_CBG%AWGF
            X = {msr1, msr2, msr3, msr4, msr5};
            truth = truth;
        case '100leaves'
            for v=1:3
                X{v} = data{v}';
            end
            truth = truelabel{1};
        case 'NGs'
            for v=1:3
                X{v} = data{v}';
            end
            truth = truelabel{1}';
        case 'WebKB'
            for v=1:3
                X{v} = data{v}';
            end
            truth = truelabel{1}';
        case '3sources'
            for v=1:3
                X{v} = data{v}';
            end
            truth = truelabel{1}';
        case 'still-2'
            for v=1:3
                X{v} = X{v}';
            end
            gt = double(gt);
            truth = gt;
        case 'Caltech101-7'
            truth=Y;
        case 'LandUse-21'
            for v=1:3
                X{v} = X{v}';
            end
            gt = double(gt);
            truth = gt;
        case 'scene15'
            for v=1:3
                X{v} = X{v}';
            end
            gt = double(gt);
            truth = gt;
        case 'EYaleB10_mtv'
            for v=1:3
                X{v} = X{v}';
            end
            gt = double(gt);
            truth = gt;
        case 'HW'
            for v=1:6
                X{v} = data{v}';
            end
            truth = truelabel{1};
        case 'cora'
            for v=1:2
                X{v} = fea{v};
            end
            truth=gnd;
        case 'Mfeat'
            for v=1:6
                X{v}=data{v}';
            end
            truth=truelabel{1};
        case 'Wikipedia'
            for v=1:2
                X{v}=data{v};
            end
            truth=Y;
        case 'CiteSeer'
            for v=1:2
                X{v}=fea{v};
            end
             gt = double(gt);
            truth = gt;
        case 'COIL20MV'
            for v=1:3
            X{v} = X{v}';
            end
           gt = double(gt);
            truth = gt;
        case 'Reuters_21578'
            for v=1:5
                X{v}=fea{v};
            end
            gt = double(gt);
            truth = gt;
        case 'scene'  
            truth = Y;
        case 'ORL'
            for v=1:3
                X{v}=fea{v};
            end
            gt = double(gt);
            truth = gt;
        case 'yale1'
            for v=1:3
                X{v}=X{v}';
            end
            gt = double(gt);
            truth = gt;
        case 'Yale3'
            for v=1:3
                X{v}=fea{v};
            end
            gt = double(gt);
            truth = gt;
        case 'AwA'
            truth = Y;
        case 'Caltech101-all'
            truth = Y;
        case 'ALOI_100'
            for v=1:4
                X{v}=fea{v};
            end
            gt = double(gt);
            truth = gt;
        case 'NUSWIDE'
            truth = Y;
        case 'cifar10'
            truth = truelabel{1};
            for v= 1:3
                X{v}=data{v}';
            end
        otherwise
            error('Unsupported dataset: %s', datasetName);
    end

    X_com = X;
    numViews = length(X);
    numSamples = size(X{1}, 1);
    
    if missingRate>(1-1/numViews)
        error('The missing rate exceeds 1-1/numViews');
    end
    % 缺失掩码保存路径
    foldFile = sprintf('dataset\\%s_folds_%.1f.mat', datasetName, missingRate);

    if exist(foldFile, 'file') == 2
        load(foldFile);  
    else
        folds = ones(numSamples, numViews);
        for i = 1:numViews
            mask = rand(numSamples, 1) > missingRate;
            folds(:, i) = mask;
        end

        % 至少保留一个视图
        validRows = any(folds == 1, 2);
        missingIndices = find(~validRows);
        for idx = missingIndices'
            viewToRecover = randi(numViews);
            folds(idx, viewToRecover) = 1;
        end

        save(foldFile, 'folds');
    end
end
